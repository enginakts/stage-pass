// StagePass Main JavaScript

document.addEventListener('DOMContentLoaded', function() {
    // Initialize tooltips
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });

    // Initialize popovers
    var popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'));
    var popoverList = popoverTriggerList.map(function (popoverTriggerEl) {
        return new bootstrap.Popover(popoverTriggerEl);
    });

    // Auto-hide alerts after 5 seconds
    setTimeout(function() {
        var alerts = document.querySelectorAll('.alert');
        alerts.forEach(function(alert) {
            var bsAlert = new bootstrap.Alert(alert);
            bsAlert.close();
        });
    }, 5000);

    // Form validation
    initializeFormValidation();
    
    // Password strength checker
    initializePasswordStrength();
    
    // Phone number formatter
    initializePhoneFormatter();
    
    // Smooth scrolling for anchor links
    initializeSmoothScrolling();
    
    // Loading states for buttons
    initializeLoadingStates();
});

// Form Validation
function initializeFormValidation() {
    const forms = document.querySelectorAll('.needs-validation');
    
    Array.from(forms).forEach(form => {
        form.addEventListener('submit', event => {
            if (!form.checkValidity()) {
                event.preventDefault();
                event.stopPropagation();
            }
            
            form.classList.add('was-validated');
        });
    });
}

// Password Strength Checker
function initializePasswordStrength() {
    const passwordInput = document.getElementById('password');
    if (!passwordInput) return;
    
    const strengthBar = createPasswordStrengthBar();
    passwordInput.parentNode.appendChild(strengthBar);
    
    passwordInput.addEventListener('input', function() {
        const password = this.value;
        const strength = calculatePasswordStrength(password);
        updatePasswordStrengthBar(strengthBar, strength);
    });
}

function createPasswordStrengthBar() {
    const container = document.createElement('div');
    container.className = 'password-strength mt-2';
    container.innerHTML = `
        <div class="progress" style="height: 5px;">
            <div class="progress-bar" role="progressbar" style="width: 0%"></div>
        </div>
        <small class="text-muted">Şifre gücü: <span class="strength-text">Zayıf</span></small>
    `;
    return container;
}

function calculatePasswordStrength(password) {
    let score = 0;
    
    if (password.length >= 8) score += 1;
    if (password.length >= 12) score += 1;
    if (/[a-z]/.test(password)) score += 1;
    if (/[A-Z]/.test(password)) score += 1;
    if (/[0-9]/.test(password)) score += 1;
    if (/[^A-Za-z0-9]/.test(password)) score += 1;
    
    return Math.min(score, 5);
}

function updatePasswordStrengthBar(container, strength) {
    const progressBar = container.querySelector('.progress-bar');
    const strengthText = container.querySelector('.strength-text');
    
    const percentage = (strength / 5) * 100;
    progressBar.style.width = percentage + '%';
    
    if (strength <= 1) {
        progressBar.className = 'progress-bar bg-danger';
        strengthText.textContent = 'Çok Zayıf';
    } else if (strength <= 2) {
        progressBar.className = 'progress-bar bg-warning';
        strengthText.textContent = 'Zayıf';
    } else if (strength <= 3) {
        progressBar.className = 'progress-bar bg-info';
        strengthText.textContent = 'Orta';
    } else if (strength <= 4) {
        progressBar.className = 'progress-bar bg-primary';
        strengthText.textContent = 'Güçlü';
    } else {
        progressBar.className = 'progress-bar bg-success';
        strengthText.textContent = 'Çok Güçlü';
    }
}

// Phone Number Formatter
function initializePhoneFormatter() {
    const phoneInputs = document.querySelectorAll('input[type="tel"]');
    
    phoneInputs.forEach(input => {
        input.addEventListener('input', function() {
            let value = this.value.replace(/\D/g, '');
            
            if (value.length >= 10) {
                value = value.substring(0, 10);
                value = value.replace(/(\d{3})(\d{3})(\d{4})/, '$1 $2 $3');
            } else if (value.length >= 7) {
                value = value.replace(/(\d{3})(\d{3})(\d+)/, '$1 $2 $3');
            } else if (value.length >= 4) {
                value = value.replace(/(\d{3})(\d+)/, '$1 $2');
            }
            
            this.value = value;
        });
    });
}

// Smooth Scrolling
function initializeSmoothScrolling() {
    const links = document.querySelectorAll('a[href^="#"]');
    
    links.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });
}

// Loading States for Buttons
function initializeLoadingStates() {
    const submitButtons = document.querySelectorAll('button[type="submit"]');
    
    submitButtons.forEach(button => {
        button.addEventListener('click', function() {
            if (this.form && this.form.checkValidity()) {
                showLoadingState(this);
            }
        });
    });
}

function showLoadingState(button) {
    const originalText = button.innerHTML;
    button.innerHTML = '<span class="loading me-2"></span>İşleniyor...';
    button.disabled = true;
    
    // Re-enable after 3 seconds (fallback)
    setTimeout(() => {
        button.innerHTML = originalText;
        button.disabled = false;
    }, 3000);
}

// Utility Functions
function showAlert(message, type = 'info') {
    const alertContainer = document.querySelector('.container');
    if (!alertContainer) return;
    
    const alertDiv = document.createElement('div');
    alertDiv.className = `alert alert-${type} alert-dismissible fade show`;
    alertDiv.innerHTML = `
        <i class="fas fa-${type === 'success' ? 'check-circle' : type === 'danger' ? 'exclamation-circle' : 'info-circle'} me-2"></i>
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    
    alertContainer.insertBefore(alertDiv, alertContainer.firstChild);
    
    // Auto-hide after 5 seconds
    setTimeout(() => {
        const bsAlert = new bootstrap.Alert(alertDiv);
        bsAlert.close();
    }, 5000);
}

function formatCurrency(amount) {
    return new Intl.NumberFormat('tr-TR', {
        style: 'currency',
        currency: 'TRY'
    }).format(amount);
}

function formatDate(date) {
    return new Intl.DateTimeFormat('tr-TR', {
        year: 'numeric',
        month: 'long',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    }).format(new Date(date));
}

// AJAX Helper
function makeRequest(url, options = {}) {
    const defaultOptions = {
        method: 'GET',
        headers: {
            'Content-Type': 'application/json',
            'X-Requested-With': 'XMLHttpRequest'
        }
    };
    
    return fetch(url, { ...defaultOptions, ...options })
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            return response.json();
        })
        .catch(error => {
            console.error('Request failed:', error);
            showAlert('Bir hata oluştu. Lütfen tekrar deneyin.', 'danger');
        });
}

// Search Functionality
function initializeSearch() {
    const searchInput = document.getElementById('search');
    if (!searchInput) return;
    
    let searchTimeout;
    searchInput.addEventListener('input', function() {
        clearTimeout(searchTimeout);
        searchTimeout = setTimeout(() => {
            performSearch(this.value);
        }, 300);
    });
}

function performSearch(query) {
    if (query.length < 2) return;
    
    makeRequest(`/api/search?q=${encodeURIComponent(query)}`)
        .then(data => {
            displaySearchResults(data);
        });
}

function displaySearchResults(results) {
    const resultsContainer = document.getElementById('search-results');
    if (!resultsContainer) return;
    
    if (results.length === 0) {
        resultsContainer.innerHTML = '<p class="text-muted">Sonuç bulunamadı.</p>';
        return;
    }
    
    const html = results.map(item => `
        <div class="search-result-item p-3 border-bottom">
            <h6 class="mb-1">${item.title}</h6>
            <p class="text-muted mb-0">${item.description}</p>
        </div>
    `).join('');
    
    resultsContainer.innerHTML = html;
}

// Export functions for global use
window.StagePass = {
    showAlert,
    formatCurrency,
    formatDate,
    makeRequest
};
