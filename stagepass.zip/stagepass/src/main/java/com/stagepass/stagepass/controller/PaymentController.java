package com.stagepass.stagepass.controller;

import com.stagepass.stagepass.model.Ticket;
import com.stagepass.stagepass.model.User;
import com.stagepass.stagepass.service.PaymentService;
import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/payments")
@RequiredArgsConstructor
public class PaymentController {

    private final PaymentService paymentService;

    @GetMapping("/{ticketId}")
    public String showPaymentForm(@PathVariable Long ticketId,
                                  HttpSession session,
                                  Model model,
                                  RedirectAttributes redirectAttributes) {
        User user = (User) session.getAttribute("user");
        if (user == null) {
            return "redirect:/login";
        }

        try {
            Ticket ticket = paymentService.getTicketForUser(ticketId, user);
            if (paymentService.isTicketAlreadyPaid(ticketId)) {
                redirectAttributes.addFlashAttribute("success", "Bu bilet için ödeme zaten tamamlanmış.");
                return "redirect:/tickets";
            }

            model.addAttribute("ticket", ticket);
            model.addAttribute("user", user);
            return "payments/payment-form";
        } catch (RuntimeException ex) {
            redirectAttributes.addFlashAttribute("error", ex.getMessage());
            return "redirect:/tickets";
        }
    }

    @PostMapping("/{ticketId}")
    public String processPayment(@PathVariable Long ticketId,
                                 @RequestParam String cardHolderName,
                                 @RequestParam String cardNumber,
                                 @RequestParam String expiryDate,
                                 @RequestParam String cvv,
                                 HttpSession session,
                                 RedirectAttributes redirectAttributes) {
        User user = (User) session.getAttribute("user");
        if (user == null) {
            return "redirect:/login";
        }

        try {
            Ticket ticket = paymentService.getTicketForUser(ticketId, user);
            paymentService.processCreditCardPayment(ticket, cardHolderName, cardNumber, expiryDate, cvv);
            redirectAttributes.addFlashAttribute("success", "Ödemeniz tamamlandı! Biletlerim sayfasına yönlendirildiniz.");
            return "redirect:/tickets";
        } catch (RuntimeException ex) {
            redirectAttributes.addFlashAttribute("error", ex.getMessage());
            return "redirect:/payments/" + ticketId;
        }
    }
}

