package com.stagepass.stagepass.repository;

import com.stagepass.stagepass.model.Show;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Repository
public interface ShowRepository extends JpaRepository<Show, Long> {
    
    List<Show> findByTheaterIdAndStatusOrderByShowDateTime(Long theaterId, Show.ShowStatus status);
    
    @Query("SELECT s FROM Show s WHERE s.theater.id = :theaterId AND s.status = 'ACTIVE' AND s.showDateTime >= :startDate AND s.showDateTime <= :endDate ORDER BY s.showDateTime")
    List<Show> findActiveShowsByTheaterAndDateRange(@Param("theaterId") Long theaterId, 
                                                   @Param("startDate") LocalDateTime startDate, 
                                                   @Param("endDate") LocalDateTime endDate);
    
    @Query("SELECT s FROM Show s WHERE s.theater.id = :theaterId AND s.status = 'ACTIVE' AND s.showDateTime >= :date ORDER BY s.showDateTime")
    List<Show> findActiveShowsByTheaterFromDate(@Param("theaterId") Long theaterId, @Param("date") LocalDateTime date);
    
    @Query("SELECT s FROM Show s WHERE s.status = 'ACTIVE' AND s.showDateTime >= :date ORDER BY s.showDateTime")
    List<Show> findActiveShowsFromDate(@Param("date") LocalDateTime date);

    @Query("SELECT s FROM Show s JOIN FETCH s.theater WHERE s.id = :id")
    Optional<Show> findByIdWithTheater(@Param("id") Long id);
    
    @Query("SELECT s FROM Show s WHERE s.theater.id = :theaterId AND s.status = 'ACTIVE' AND LOWER(s.title) LIKE LOWER(CONCAT('%', :title, '%')) ORDER BY s.showDateTime")
    List<Show> findActiveShowsByTheaterAndTitleContaining(@Param("theaterId") Long theaterId, @Param("title") String title);

    Optional<Show> findByTitleIgnoreCaseAndTheaterId(String title, Long theaterId);
}
