package com.stagepass.stagepass.controller;

import com.stagepass.stagepass.model.Seat;
import com.stagepass.stagepass.model.Show;
import com.stagepass.stagepass.model.User;
import com.stagepass.stagepass.service.BookingService;
import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;
import java.util.Objects;
import java.util.Set;

@Controller
@RequestMapping("/shows")
@RequiredArgsConstructor
public class ShowBookingController {

    private final BookingService bookingService;

    @GetMapping("/{showId}/seats")
    public String showSeatSelection(@PathVariable Long showId,
                                    HttpSession session,
                                    Model model,
                                    RedirectAttributes redirectAttributes) {
        User user = (User) session.getAttribute("user");
        if (user == null) {
            return "redirect:/login";
        }

        try {
            Show show = bookingService.getShowWithTheater(showId);
            List<Seat> seats = bookingService.getSeatsForShow(showId);
            Set<Long> occupiedSeatIds = bookingService.getOccupiedSeatIds(showId);

            model.addAttribute("show", show);
            model.addAttribute("seats", seats);
            model.addAttribute("occupiedSeatIds", occupiedSeatIds);
            model.addAttribute("availableSeatCount", seats.size() - occupiedSeatIds.size());
            model.addAttribute("totalSeatCount", seats.size());
            model.addAttribute("user", user);
            return "shows/seat-selection";
        } catch (IllegalArgumentException ex) {
            redirectAttributes.addFlashAttribute("error", ex.getMessage());
            return "redirect:/search";
        }
    }

    @PostMapping("/{showId}/seats/book")
    public String bookSeat(@PathVariable Long showId,
                           @RequestParam Long seatId,
                           HttpSession session,
                           RedirectAttributes redirectAttributes) {
        User user = (User) session.getAttribute("user");
        if (user == null) {
            return "redirect:/login";
        }

        try {
            var ticket = bookingService.bookSeat(
                Objects.requireNonNull(showId, "showId"),
                Objects.requireNonNull(seatId, "seatId"),
                Objects.requireNonNull(user.getId(), "userId")
            );
            redirectAttributes.addFlashAttribute("success", "Koltuk başarıyla rezerve edildi! Ödeme adımına yönlendiriliyorsunuz.");
            return "redirect:/payments/" + ticket.getId();
        } catch (RuntimeException ex) {
            redirectAttributes.addFlashAttribute("error", ex.getMessage());
        }

        return "redirect:/shows/" + showId + "/seats";
    }
}

