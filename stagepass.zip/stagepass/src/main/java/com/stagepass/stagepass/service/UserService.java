package com.stagepass.stagepass.service;

import com.stagepass.stagepass.model.User;
import com.stagepass.stagepass.repository.UserRepository;
import jakarta.persistence.EntityManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.Optional;

@Service
@Transactional
public class UserService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;
    
    @Autowired
    private EntityManager entityManager;

    public User registerUser(User user) {
        // Email kontrolü
        if (userRepository.existsByEmail(user.getEmail())) {
            throw new RuntimeException("Bu email adresi zaten kullanılıyor!");
        }

        // Şifreyi hash'le
        String plainPassword = user.getPassword();
        if (plainPassword == null || plainPassword.trim().isEmpty()) {
            throw new RuntimeException("Şifre boş olamaz!");
        }
        
        user.setPassword(passwordEncoder.encode(plainPassword));
        user.setRole(User.Role.USER);
        user.setIsActive(true);
        user.setCreatedAt(LocalDateTime.now());
        user.setTotalShowsAttended(0);
        user.setRewardPoints(0);

        User savedUser = userRepository.save(user);
        // Veritabanına hemen yazıldığından emin ol
        entityManager.flush();
        
        return savedUser;
    }

    public User loginUser(String email, String password) {
        // Önce kullanıcıyı bul (aktif olmasa bile)
        Optional<User> userOpt = userRepository.findByEmail(email);
        
        if (!userOpt.isPresent()) {
            throw new RuntimeException("Bu email adresi ile kayıtlı kullanıcı bulunamadı!");
        }
        
        User user = userOpt.get();
        
        // Kullanıcı aktif mi kontrol et
        if (!user.getIsActive()) {
            throw new RuntimeException("Hesabınız aktif değil! Lütfen yönetici ile iletişime geçin.");
        }
        
        // Şifre kontrolü
        if (user.getPassword() == null || user.getPassword().trim().isEmpty()) {
            throw new RuntimeException("Kullanıcı şifresi veritabanında bulunamadı! Lütfen yönetici ile iletişime geçin.");
        }
        
        // BCrypt hash formatı kontrolü
        if (!user.getPassword().startsWith("$2a$") && !user.getPassword().startsWith("$2b$")) {
            throw new RuntimeException("Şifre formatı hatalı! Kullanıcı şifresi düzgün hash'lenmemiş. Lütfen yönetici ile iletişime geçin.");
        }
        
        // Şifre doğrulama
        if (!passwordEncoder.matches(password, user.getPassword())) {
            throw new RuntimeException("Email veya şifre hatalı!");
        }
        
        // Başarılı giriş - son giriş zamanını güncelle
        user.setLastLoginAt(LocalDateTime.now());
        userRepository.save(user);
        entityManager.flush();
        
        return user;
    }

    public User findByEmail(String email) {
        return userRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("Kullanıcı bulunamadı!"));
    }

    public User findById(Long id) {
        return userRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Kullanıcı bulunamadı!"));
    }

    public User updateUser(User user) {
        return userRepository.save(user);
    }

    public boolean existsByEmail(String email) {
        return userRepository.existsByEmail(email);
    }
}
