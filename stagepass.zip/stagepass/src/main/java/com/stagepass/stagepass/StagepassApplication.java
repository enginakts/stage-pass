package com.stagepass.stagepass;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StagepassApplication {

	public static void main(String[] args) {
		SpringApplication.run(StagepassApplication.class, args);
	}

}
