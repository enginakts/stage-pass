package com.stagepass.stagepass.model;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Set;

@Entity
@Table(name = "shows")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Show {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(nullable = false)
    private String title;
    
    @Column
    private String description;
    
    @Column(nullable = false)
    private LocalDateTime showDateTime;
    
    @Column(nullable = false)
    private Integer duration; // dakika cinsinden
    
    @Column(nullable = false)
    private BigDecimal basePrice;
    
    @Column
    private String imageUrl;
    
    @Column
    private String genre;
    
    @Column
    private String ageLimit;
    
    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private ShowStatus status = ShowStatus.ACTIVE;
    
    @Column(nullable = false)
    private LocalDateTime createdAt = LocalDateTime.now();
    
    // Gösteri hangi tiyatroda
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "theater_id", nullable = false)
    private Theater theater;
    
    // Gösterinin biletleri
    @OneToMany(mappedBy = "show", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private Set<Ticket> tickets;
    
    public enum ShowStatus {
        ACTIVE, CANCELLED, COMPLETED, POSTPONED
    }
}
