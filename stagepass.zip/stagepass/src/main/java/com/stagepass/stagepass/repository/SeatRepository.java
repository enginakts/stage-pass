package com.stagepass.stagepass.repository;

import com.stagepass.stagepass.model.Seat;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface SeatRepository extends JpaRepository<Seat, Long> {
    
    List<Seat> findByTheaterIdAndIsActiveTrueOrderByRowNumberAscSeatNumberAsc(Long theaterId);
    
    @Query("SELECT s FROM Seat s WHERE s.theater.id = :theaterId AND s.isActive = true AND s.id NOT IN " +
           "(SELECT t.seat.id FROM Ticket t WHERE t.show.id = :showId AND t.status IN ('ACTIVE', 'USED')) " +
           "ORDER BY s.rowNumber, s.seatNumber")
    List<Seat> findAvailableSeatsByTheaterAndShow(@Param("theaterId") Long theaterId, @Param("showId") Long showId);
    
    @Query("SELECT s FROM Seat s WHERE s.theater.id = :theaterId AND s.isActive = true AND s.seatType = :seatType AND s.id NOT IN " +
           "(SELECT t.seat.id FROM Ticket t WHERE t.show.id = :showId AND t.status IN ('ACTIVE', 'USED')) " +
           "ORDER BY s.rowNumber, s.seatNumber")
    List<Seat> findAvailableSeatsByTheaterAndShowAndSeatType(@Param("theaterId") Long theaterId, 
                                                       @Param("showId") Long showId, 
                                                       @Param("seatType") Seat.SeatType seatType);
    
    @Query("SELECT CASE WHEN COUNT(t) > 0 THEN true ELSE false END FROM Ticket t WHERE t.seat.id = :seatId AND t.show.id = :showId AND t.status IN ('ACTIVE', 'USED')")
    boolean isSeatOccupiedForShow(@Param("seatId") Long seatId, @Param("showId") Long showId);
    
    Optional<Seat> findByTheaterIdAndSeatNumberAndRowNumberAndIsActiveTrue(Long theaterId, String seatNumber, String rowNumber);

    long countByTheaterId(Long theaterId);
}
