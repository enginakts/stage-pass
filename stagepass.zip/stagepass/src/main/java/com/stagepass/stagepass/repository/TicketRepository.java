package com.stagepass.stagepass.repository;

import com.stagepass.stagepass.model.Ticket;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Repository
public interface TicketRepository extends JpaRepository<Ticket, Long> {
    
    Optional<Ticket> findByTicketNumber(String ticketNumber);
    
    List<Ticket> findByUserIdOrderByPurchaseDateDesc(Long userId);
    
    List<Ticket> findByUserIdAndStatusOrderByPurchaseDateDesc(Long userId, Ticket.TicketStatus status);
    
    @Query("SELECT t FROM Ticket t WHERE t.user.id = :userId AND t.status = 'ACTIVE' AND t.show.showDateTime > :now")
    List<Ticket> findActiveUpcomingTicketsByUserId(@Param("userId") Long userId, @Param("now") LocalDateTime now);
    
    @Query("SELECT t FROM Ticket t WHERE t.user.id = :userId AND t.status = 'ACTIVE' AND t.show.showDateTime > :now AND t.show.showDateTime <= :deadline")
    List<Ticket> findCancellableTicketsByUserId(@Param("userId") Long userId, 
                                                @Param("now") LocalDateTime now, 
                                                @Param("deadline") LocalDateTime deadline);
    
    @Query("SELECT COUNT(t) FROM Ticket t WHERE t.user.id = :userId AND t.status = 'USED'")
    Long countUsedTicketsByUserId(@Param("userId") Long userId);
    
    @Query("SELECT t FROM Ticket t WHERE t.seat.id = :seatId AND t.show.id = :showId AND t.status IN ('ACTIVE', 'USED')")
    Optional<Ticket> findActiveTicketBySeatAndShow(@Param("seatId") Long seatId, @Param("showId") Long showId);
    
    @Query("SELECT t FROM Ticket t WHERE t.show.id = :showId AND t.status = 'ACTIVE'")
    List<Ticket> findActiveTicketsByShowId(@Param("showId") Long showId);

    @Query("SELECT t.seat.id FROM Ticket t WHERE t.show.id = :showId AND t.status IN ('ACTIVE', 'USED')")
    List<Long> findOccupiedSeatIdsByShowId(@Param("showId") Long showId);

    Optional<Ticket> findByIdAndUserId(Long id, Long userId);

    List<Ticket> findTop5ByOrderByPurchaseDateDesc();
}
