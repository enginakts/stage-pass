package com.stagepass.stagepass.service;

import com.stagepass.stagepass.model.Seat;
import com.stagepass.stagepass.model.Show;
import com.stagepass.stagepass.model.Ticket;
import com.stagepass.stagepass.model.User;
import com.stagepass.stagepass.repository.SeatRepository;
import com.stagepass.stagepass.repository.ShowRepository;
import com.stagepass.stagepass.repository.TicketRepository;
import com.stagepass.stagepass.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.lang.NonNull;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class BookingService {

    private final ShowRepository showRepository;
    private final SeatRepository seatRepository;
    private final TicketRepository ticketRepository;
    private final UserRepository userRepository;

    @Transactional(readOnly = true)
    public Show getShowWithTheater(Long showId) {
        return showRepository.findByIdWithTheater(showId)
            .orElseThrow(() -> new IllegalArgumentException("Gösteri bulunamadı."));
    }

    @Transactional(readOnly = true)
    public List<Seat> getSeatsForShow(Long showId) {
        Show show = getShowWithTheater(showId);
        return seatRepository.findByTheaterIdAndIsActiveTrueOrderByRowNumberAscSeatNumberAsc(
            show.getTheater().getId()
        );
    }

    @Transactional(readOnly = true)
    public Set<Long> getOccupiedSeatIds(Long showId) {
        return new HashSet<>(ticketRepository.findOccupiedSeatIdsByShowId(showId));
    }

    @Transactional
    public Ticket bookSeat(@NonNull Long showId, @NonNull Long seatId, @NonNull Long userId) {
        Show show = getShowWithTheater(showId);
        Seat seat = seatRepository.findById(seatId)
            .orElseThrow(() -> new IllegalArgumentException("Koltuk bulunamadı."));

        Long seatTheaterId = seat.getTheater() != null ? seat.getTheater().getId() : null;
        Long showTheaterId = show.getTheater() != null ? show.getTheater().getId() : null;
        if (seatTheaterId == null || showTheaterId == null || !seatTheaterId.equals(showTheaterId)) {
            throw new IllegalStateException("Seçilen koltuk bu gösteriye ait değil.");
        }

        if (ticketRepository.findActiveTicketBySeatAndShow(seatId, showId).isPresent()) {
            throw new IllegalStateException("Koltuk zaten başka bir kullanıcı tarafından seçilmiş.");
        }

        User user = userRepository.findById(userId)
            .orElseThrow(() -> new IllegalArgumentException("Kullanıcı bulunamadı."));

        Ticket ticket = new Ticket();
        ticket.setTicketNumber(generateTicketNumber(showId, seatId));
        ticket.setShow(show);
        ticket.setSeat(seat);
        ticket.setUser(user);

        BigDecimal price = seat.getPrice() != null ? seat.getPrice() : show.getBasePrice();
        ticket.setPrice(price);
        ticket.setTotalPrice(price);
        ticket.setStatus(Ticket.TicketStatus.ACTIVE);
        ticket.setPurchaseDate(LocalDateTime.now());

        Ticket savedTicket = ticketRepository.save(ticket);

        user.setTotalShowsAttended(user.getTotalShowsAttended() + 1);
        user.setRewardPoints(user.getRewardPoints() + 10);

        return savedTicket;
    }

    private String generateTicketNumber(Long showId, Long seatId) {
        String randomPart = UUID.randomUUID().toString().replace("-", "").substring(0, 6).toUpperCase();
        return String.format("STG-%d-%d-%s", showId, seatId, randomPart);
    }
}

