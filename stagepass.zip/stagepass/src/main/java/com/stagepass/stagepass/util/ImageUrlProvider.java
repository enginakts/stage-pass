package com.stagepass.stagepass.util;

import java.util.Locale;
import java.util.UUID;

public final class ImageUrlProvider {

    private ImageUrlProvider() {
    }

    private static String sanitizeSeed(String seed) {
        String base = (seed == null || seed.isBlank()) ? UUID.randomUUID().toString() : seed;
        return base
            .toLowerCase(Locale.ROOT)
            .replaceAll("[^a-z0-9]+", "-")
            .replaceAll("(^-+|-+$)", "");
    }

    private static String buildUrl(String category, String seed) {
        String sanitized = sanitizeSeed(seed);
        return "https://picsum.photos/seed/" + category + "-" + sanitized + "/900/600";
    }

    public static String theaterImage(String seed) {
        return buildUrl("theater", seed);
    }

    public static String showImage(String seed) {
        return buildUrl("show", seed);
    }

    public static String cityImage(String seed) {
        return buildUrl("city", seed);
    }
}

