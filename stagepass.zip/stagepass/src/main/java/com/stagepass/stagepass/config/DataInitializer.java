package com.stagepass.stagepass.config;

import com.stagepass.stagepass.model.*;
import com.stagepass.stagepass.repository.*;
import com.stagepass.stagepass.util.ImageUrlProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;

@Component
public class DataInitializer implements CommandLineRunner {

    @Autowired
    private UserRepository userRepository;
    
    @Autowired
    private CityRepository cityRepository;
    
    @Autowired
    private TheaterRepository theaterRepository;
    
    @Autowired
    private ShowRepository showRepository;
    
    @Autowired
    private SeatRepository seatRepository;
    
    @Autowired
    private PasswordEncoder passwordEncoder;

    @Override
    public void run(String... args) throws Exception {
        if (userRepository.count() == 0) {
            initializeData();
        }
    }

    private void initializeData() {
        // Şehirler oluştur
        City istanbul = createCity("İstanbul", "Türkiye", "Türkiye'nin en büyük şehri");
        City ankara = createCity("Ankara", "Türkiye", "Türkiye'nin başkenti");
        City izmir = createCity("İzmir", "Türkiye", "Ege'nin incisi");
        
        // Tiyatrolar oluştur
        Theater istanbulTheater1 = createTheater("İstanbul Şehir Tiyatrosu", "Kadıköy, İstanbul", 
            "İstanbul'un en köklü tiyatrosu", "0212 123 45 67", "info@istanbultiyatro.com", 200, istanbul, ImageUrlProvider.theaterImage("istanbul-1"));
        
        Theater istanbulTheater2 = createTheater("Beyoğlu Sanat Merkezi", "Beyoğlu, İstanbul", 
            "Modern sanat merkezi", "0212 234 56 78", "info@beyoglusanat.com", 150, istanbul, ImageUrlProvider.theaterImage("istanbul-2"));
        
        Theater ankaraTheater1 = createTheater("Ankara Devlet Tiyatrosu", "Kızılay, Ankara", 
            "Ankara'nın en büyük tiyatrosu", "0312 345 67 89", "info@ankaratiyatro.com", 300, ankara, ImageUrlProvider.theaterImage("ankara-1"));
        
        Theater izmirTheater1 = createTheater("İzmir Sanat Merkezi", "Konak, İzmir", 
            "İzmir'in sanat merkezi", "0232 456 78 90", "info@izmirsanat.com", 180, izmir, ImageUrlProvider.theaterImage("izmir-1"));

        // Koltuklar oluştur
        createSeatsForTheater(istanbulTheater1, 200);
        createSeatsForTheater(istanbulTheater2, 150);
        createSeatsForTheater(ankaraTheater1, 300);
        createSeatsForTheater(izmirTheater1, 180);

        // Gösteriler oluştur
        createShowsForTheater(istanbulTheater1);
        createShowsForTheater(istanbulTheater2);
        createShowsForTheater(ankaraTheater1);
        createShowsForTheater(izmirTheater1);

        // Test kullanıcıları oluştur
        createTestUsers();
    }

    private City createCity(String name, String country, String description) {
        City city = new City();
        city.setName(name);
        city.setCountry(country);
        city.setDescription(description);
        city.setIsActive(true);
        return cityRepository.save(city);
    }

    private Theater createTheater(String name, String address, String description, 
                                String phoneNumber, String email, Integer totalSeats, City city, String imageUrl) {
        Theater theater = new Theater();
        theater.setName(name);
        theater.setAddress(address);
        theater.setDescription(description);
        theater.setPhoneNumber(phoneNumber);
        theater.setEmail(email);
        theater.setTotalSeats(totalSeats);
        theater.setCity(city);
        theater.setIsActive(true);
        theater.setOpenedDate(LocalDate.now());
        theater.setImageUrl(imageUrl);
        return theaterRepository.save(theater);
    }

    private void createSeatsForTheater(Theater theater, int totalSeats) {
        String[] sections = {"A", "B", "C", "D", "E"};
        int seatsPerRow = 10;
        int rows = totalSeats / seatsPerRow;
        
        for (int section = 0; section < sections.length && section < rows; section++) {
            for (int row = 1; row <= 4; row++) {
                for (int seat = 1; seat <= seatsPerRow; seat++) {
                    Seat seatEntity = new Seat();
                    seatEntity.setSeatNumber(String.valueOf(seat));
                    seatEntity.setRowNumber(sections[section] + row);
                    seatEntity.setSection(sections[section]);
                    
                    // Koltuk tipi ve fiyat belirleme
                    if (section == 0) { // VIP bölüm
                        seatEntity.setSeatType(Seat.SeatType.VIP);
                        seatEntity.setPrice(new BigDecimal("150.00"));
                    } else if (section == 1) { // Premium bölüm
                        seatEntity.setSeatType(Seat.SeatType.PREMIUM);
                        seatEntity.setPrice(new BigDecimal("100.00"));
                    } else { // Standart bölüm
                        seatEntity.setSeatType(Seat.SeatType.STANDARD);
                        seatEntity.setPrice(new BigDecimal("50.00"));
                    }
                    
                    seatEntity.setTheater(theater);
                    seatEntity.setIsActive(true);
                    seatRepository.save(seatEntity);
                }
            }
        }
    }

    private void createShowsForTheater(Theater theater) {
        List<String> showTitles = Arrays.asList(
            "Hamlet", "Romeo ve Juliet", "Macbeth", "Kral Lear", "Othello",
            "Vanya Dayı", "Üç Kız Kardeş", "Vişne Bahçesi", "Martı", "Kafkas Tebeşir Dairesi"
        );
        
        List<String> genres = Arrays.asList("Drama", "Komedi", "Tragedya", "Müzikal", "Dans");
        
        for (int i = 0; i < 5; i++) {
            Show show = new Show();
            show.setTitle(showTitles.get(i % showTitles.size()));
            show.setDescription(show.getTitle() + " - Büyük bir tiyatro eseri");
            show.setShowDateTime(LocalDateTime.now().plusDays(i + 1).plusHours(19)); // Gelecek günlerde saat 19:00
            show.setDuration(120 + (i * 30)); // 120-240 dakika arası
            show.setBasePrice(new BigDecimal("50.00"));
            show.setGenre(genres.get(i % genres.size()));
            show.setAgeLimit("12+");
            show.setTheater(theater);
            show.setStatus(Show.ShowStatus.ACTIVE);
            show.setImageUrl(ImageUrlProvider.showImage(show.getTitle() + "-" + theater.getName() + "-" + i));
            show.setCreatedAt(LocalDateTime.now());
            showRepository.save(show);
        }
    }

    private void createTestUsers() {
        // Admin kullanıcı
        User admin = new User();
        admin.setEmail("admin@stagepass.com");
        admin.setPassword(passwordEncoder.encode("admin123"));
        admin.setFirstName("Admin");
        admin.setLastName("User");
        admin.setPhoneNumber("0555 000 00 00");
        admin.setRole(User.Role.ADMIN);
        admin.setIsActive(true);
        admin.setCreatedAt(LocalDateTime.now());
        admin.setTotalShowsAttended(0);
        admin.setRewardPoints(0);
        userRepository.save(admin);

        // Test kullanıcıları
        for (int i = 1; i <= 5; i++) {
            User user = new User();
            user.setEmail("user" + i + "@test.com");
            user.setPassword(passwordEncoder.encode("password123"));
            user.setFirstName("Test");
            user.setLastName("User" + i);
            user.setPhoneNumber("0555 " + String.format("%03d", i * 111) + " " + String.format("%02d", i * 11) + " " + String.format("%02d", i * 11));
            user.setRole(User.Role.USER);
            user.setIsActive(true);
            user.setCreatedAt(LocalDateTime.now());
            user.setTotalShowsAttended(0);
            user.setRewardPoints(0);
            userRepository.save(user);
        }
    }
}
