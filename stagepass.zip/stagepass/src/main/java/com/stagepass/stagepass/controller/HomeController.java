package com.stagepass.stagepass.controller;

import com.stagepass.stagepass.model.City;
import com.stagepass.stagepass.model.Show;
import com.stagepass.stagepass.model.Theater;
import com.stagepass.stagepass.model.User;
import com.stagepass.stagepass.repository.CityRepository;
import com.stagepass.stagepass.repository.ShowRepository;
import com.stagepass.stagepass.repository.TheaterRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import jakarta.servlet.http.HttpSession;
import java.time.LocalDateTime;
import java.util.List;

@Controller
public class HomeController {

    @Autowired
    private CityRepository cityRepository;
    
    @Autowired
    private TheaterRepository theaterRepository;
    
    @Autowired
    private ShowRepository showRepository;

    @GetMapping("/")
    public String home(HttpSession session, Model model) {
        User user = (User) session.getAttribute("user");
        if (user == null) {
            return "redirect:/login";
        }
        
        // Aktif şehirleri getir
        List<City> cities = cityRepository.findByIsActiveTrueOrderByName();
        model.addAttribute("cities", cities);
        
        // Popüler gösterileri getir (gelecek tarihli, aktif)
        List<Show> popularShows = showRepository.findActiveShowsFromDate(LocalDateTime.now());
        if (popularShows.size() > 6) {
            popularShows = popularShows.subList(0, 6);
        }
        model.addAttribute("popularShows", popularShows);

        List<Theater> theaters = theaterRepository.findActiveTheatersWithCity();
        model.addAttribute("theaters", theaters);
        
        // Kullanıcı bilgilerini ekle (lazy loading sorunlarını önlemek için sadece temel bilgiler)
        model.addAttribute("user", user);
        
        return "home";
    }

    @GetMapping("/search")
    public String search(@RequestParam(required = false) String cityId,
                        @RequestParam(required = false) String theaterId,
                        @RequestParam(required = false) String date,
                        @RequestParam(required = false) String keyword,
                        HttpSession session, Model model) {
        
        User user = (User) session.getAttribute("user");
        if (user == null) {
            return "redirect:/login";
        }
        
        List<City> cities = cityRepository.findByIsActiveTrueOrderByName();
        model.addAttribute("cities", cities);
        
        // Arama sonuçları
        if (cityId != null && !cityId.isEmpty()) {
            List<Theater> theaters = theaterRepository.findActiveTheatersByCityId(Long.parseLong(cityId));
            model.addAttribute("theaters", theaters);
            model.addAttribute("selectedCityId", cityId);
        }
        
        if (theaterId != null && !theaterId.isEmpty()) {
            List<Show> shows = showRepository.findActiveShowsByTheaterFromDate(
                Long.parseLong(theaterId), LocalDateTime.now());
            model.addAttribute("shows", shows);
            model.addAttribute("selectedTheaterId", theaterId);
        }
        
        model.addAttribute("user", user);
        return "search";
    }
}
