package com.stagepass.stagepass.model;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

import java.time.LocalDateTime;

@Entity
@Table(name = "user_rewards")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class UserReward {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(nullable = false)
    private String rewardName;
    
    @Column
    private String description;
    
    @Column(nullable = false)
    private Integer pointsRequired;
    
    @Column(nullable = false)
    private Integer pointsEarned;
    
    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private RewardStatus status = RewardStatus.ACTIVE;
    
    @Column(nullable = false)
    private LocalDateTime earnedDate = LocalDateTime.now();
    
    @Column
    private LocalDateTime usedDate;
    
    // Ödül hangi kullanıcıya ait
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;
    
    public enum RewardStatus {
        ACTIVE, USED, EXPIRED
    }
}
