package com.stagepass.stagepass.model;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

import java.time.LocalDate;
import java.util.Set;

@Entity
@Table(name = "theaters")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Theater {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(nullable = false)
    private String name;
    
    @Column
    private String address;
    
    @Column
    private String description;
    
    @Column
    private String phoneNumber;
    
    @Column
    private String email;
    
    @Column(nullable = false)
    private Integer totalSeats;

    @Column
    private LocalDate openedDate;

    @Column
    private String imageUrl;
    
    @Column(nullable = false)
    private Boolean isActive = true;
    
    // Tiyatro hangi şehirde
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "city_id", nullable = false)
    private City city;
    
    // Tiyatronun gösterileri
    @OneToMany(mappedBy = "theater", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private Set<Show> shows;
    
    // Tiyatronun koltukları
    @OneToMany(mappedBy = "theater", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private Set<Seat> seats;
}
