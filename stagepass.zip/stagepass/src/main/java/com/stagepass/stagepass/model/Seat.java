package com.stagepass.stagepass.model;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

import java.math.BigDecimal;

@Entity
@Table(name = "seats")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Seat {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(nullable = false)
    private String seatNumber;
    
    @Column(nullable = false)
    private String rowNumber;
    
    @Column(nullable = false)
    private String section;
    
    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private SeatType seatType = SeatType.STANDARD;
    
    @Column(nullable = false)
    private BigDecimal price;
    
    @Column(nullable = false)
    private Boolean isActive = true;
    
    // Koltuk hangi tiyatroda
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "theater_id", nullable = false)
    private Theater theater;
    
    // Koltuk hangi biletle rezerve edilmiş
    @OneToOne(mappedBy = "seat", fetch = FetchType.LAZY)
    private Ticket ticket;
    
    public enum SeatType {
        STANDARD, VIP, PREMIUM, STUDENT, SENIOR
    }
}
