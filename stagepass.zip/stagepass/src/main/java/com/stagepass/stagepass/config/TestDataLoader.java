package com.stagepass.stagepass.config;

import com.stagepass.stagepass.model.City;
import com.stagepass.stagepass.model.Show;
import com.stagepass.stagepass.model.Theater;
import com.stagepass.stagepass.model.User;
import com.stagepass.stagepass.repository.CityRepository;
import com.stagepass.stagepass.repository.ShowRepository;
import com.stagepass.stagepass.repository.TheaterRepository;
import com.stagepass.stagepass.repository.UserRepository;
import com.stagepass.stagepass.util.ImageUrlProvider;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Component
public class TestDataLoader implements CommandLineRunner {

    private static final Logger log = LoggerFactory.getLogger(TestDataLoader.class);

    private final CityRepository cityRepository;
    private final TheaterRepository theaterRepository;
    private final ShowRepository showRepository;
    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    public TestDataLoader(CityRepository cityRepository,
                          TheaterRepository theaterRepository,
                          ShowRepository showRepository,
                          UserRepository userRepository,
                          PasswordEncoder passwordEncoder) {
        this.cityRepository = cityRepository;
        this.theaterRepository = theaterRepository;
        this.showRepository = showRepository;
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    public void run(String... args) {
        City bursa = cityRepository.findByNameIgnoreCase("Bursa")
            .orElseGet(() -> {
                City city = new City();
                city.setName("Bursa");
                city.setCountry("Türkiye");
                city.setDescription("Uludağ’ın eteklerinde kültür şehri");
                city.setIsActive(true);
                return cityRepository.save(city);
            });

        Theater bursaTheater = theaterRepository.findByNameIgnoreCaseAndCityId("Bursa Devlet Tiyatrosu", bursa.getId())
            .orElseGet(() -> {
                Theater theater = new Theater();
                theater.setName("Bursa Devlet Tiyatrosu");
                theater.setAddress("Osmangazi, Bursa");
                theater.setDescription("Marmara bölgesinin önemli tiyatrosu");
                theater.setPhoneNumber("0224 123 45 67");
                theater.setEmail("info@bursatiyatro.com");
                theater.setTotalSeats(250);
                theater.setIsActive(true);
                theater.setCity(bursa);
                theater.setImageUrl(ImageUrlProvider.theaterImage(theater.getName()));
                return theaterRepository.save(theater);
            });

        showRepository.findByTitleIgnoreCaseAndTheaterId("Uludağ Efsanesi", bursaTheater.getId())
            .orElseGet(() -> {
                Show show = new Show();
                show.setTitle("Uludağ Efsanesi");
                show.setDescription("Bursa’nın efsanelerini sahneye taşıyan özel gösteri");
                show.setShowDateTime(LocalDateTime.now().plusDays(5).withHour(20).withMinute(0));
                show.setDuration(120);
                show.setBasePrice(new BigDecimal("85.00"));
                show.setGenre("Drama");
                show.setAgeLimit("10+");
                show.setStatus(Show.ShowStatus.ACTIVE);
                show.setImageUrl(ImageUrlProvider.showImage(show.getTitle()));
                show.setCreatedAt(LocalDateTime.now());
                show.setTheater(bursaTheater);
                return showRepository.save(show);
            });

        userRepository.findByEmail("demo@stagepass.com")
            .orElseGet(() -> {
                User user = new User();
                user.setEmail("demo@stagepass.com");
                user.setPassword(passwordEncoder.encode("demo123"));
                user.setFirstName("Demo");
                user.setLastName("Kullanıcı");
                user.setPhoneNumber("0555 111 22 33");
                user.setRole(User.Role.USER);
                user.setIsActive(true);
                user.setCreatedAt(LocalDateTime.now());
                user.setTotalShowsAttended(0);
                user.setRewardPoints(0);
                return userRepository.save(user);
            });

        log.info("TestDataLoader -> users: {}, cities: {}, shows: {}",
            userRepository.count(),
            cityRepository.count(),
            showRepository.count());
    }
}

