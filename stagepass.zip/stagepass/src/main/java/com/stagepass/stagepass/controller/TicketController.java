package com.stagepass.stagepass.controller;

import com.stagepass.stagepass.model.Payment;
import com.stagepass.stagepass.model.Ticket;
import com.stagepass.stagepass.model.User;
import com.stagepass.stagepass.repository.PaymentRepository;
import com.stagepass.stagepass.repository.TicketRepository;
import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Controller
@RequestMapping("/tickets")
@RequiredArgsConstructor
public class TicketController {

    private final TicketRepository ticketRepository;
    private final PaymentRepository paymentRepository;
    @GetMapping
    public String listTickets(HttpSession session, Model model) {
        User user = (User) session.getAttribute("user");
        if (user == null) {
            return "redirect:/login";
        }

        List<Ticket> tickets = ticketRepository.findByUserIdOrderByPurchaseDateDesc(user.getId());
        Set<Long> paidTicketIds = paymentRepository.findByUserIdOrderByPaymentDateDesc(user.getId()).stream()
            .filter(payment -> payment.getStatus() == Payment.PaymentStatus.COMPLETED)
            .map(payment -> payment.getTicket().getId())
            .collect(Collectors.toSet());
        model.addAttribute("tickets", tickets);
        model.addAttribute("user", user);
        model.addAttribute("paidTicketIds", paidTicketIds);
        return "tickets/list";
    }
}

