package com.stagepass.stagepass.controller;

import com.stagepass.stagepass.model.*;
import com.stagepass.stagepass.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.io.FileWriter;
import java.io.IOException;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Optional;

@Controller
public class TestController {

    @Autowired
    private UserRepository userRepository;
    
    @Autowired
    private CityRepository cityRepository;
    
    @Autowired
    private TheaterRepository theaterRepository;
    
    @Autowired
    private ShowRepository showRepository;
    
    @Autowired
    private SeatRepository seatRepository;
    
    @Autowired
    private TicketRepository ticketRepository;
    
    @Autowired
    private PaymentRepository paymentRepository;
    
    @Autowired
    private UserRewardRepository userRewardRepository;
    
    @Autowired
    private PasswordEncoder passwordEncoder;

    @GetMapping("/test/data")
    public String testData(Model model) {
        model.addAttribute("userCount", userRepository.count());
        model.addAttribute("cityCount", cityRepository.count());
        model.addAttribute("theaterCount", theaterRepository.count());
        model.addAttribute("showCount", showRepository.count());
        model.addAttribute("seatCount", seatRepository.count());
        model.addAttribute("ticketCount", ticketRepository.count());
        model.addAttribute("paymentCount", paymentRepository.count());
        model.addAttribute("rewardCount", userRewardRepository.count());
        
        model.addAttribute("users", userRepository.findAll());
        model.addAttribute("cities", cityRepository.findAll());
        model.addAttribute("theaters", theaterRepository.findAll());
        model.addAttribute("shows", showRepository.findAll());
        
        return "test/data";
    }
    
    @GetMapping("/test/password-check")
    public ResponseEntity<String> checkPassword(@RequestParam String email, @RequestParam String password) {
        StringBuilder result = new StringBuilder();
        result.append("=== ŞİFRE KONTROL RAPORU ===\n\n");
        
        Optional<User> userOpt = userRepository.findByEmail(email);
        if (!userOpt.isPresent()) {
            result.append("❌ Kullanıcı bulunamadı: ").append(email).append("\n");
            return ResponseEntity.ok(result.toString());
        }
        
        User user = userOpt.get();
        result.append("✅ Kullanıcı bulundu:\n");
        result.append("  ID: ").append(user.getId()).append("\n");
        result.append("  Email: ").append(user.getEmail()).append("\n");
        result.append("  Ad Soyad: ").append(user.getFirstName()).append(" ").append(user.getLastName()).append("\n");
        result.append("  Aktif: ").append(user.getIsActive() ? "Evet" : "Hayır").append("\n");
        result.append("  Rol: ").append(user.getRole()).append("\n\n");
        
        result.append("Şifre Bilgileri:\n");
        result.append("  Veritabanındaki Hash: ").append(user.getPassword()).append("\n");
        result.append("  Hash Uzunluğu: ").append(user.getPassword().length()).append(" karakter\n");
        result.append("  Hash BCrypt formatında mı: ").append(user.getPassword().startsWith("$2a$") || user.getPassword().startsWith("$2b$") ? "Evet" : "HAYIR!").append("\n\n");
        
        result.append("Şifre Doğrulama Testi:\n");
        result.append("  Girilen Şifre: ").append(password).append("\n");
        boolean matches = passwordEncoder.matches(password, user.getPassword());
        result.append("  Sonuç: ").append(matches ? "✅ ŞİFRE DOĞRU" : "❌ ŞİFRE YANLIŞ").append("\n\n");
        
        // Test: Yeni bir hash oluştur ve karşılaştır
        String newHash = passwordEncoder.encode(password);
        result.append("Test Hash Oluşturma:\n");
        result.append("  Yeni Hash: ").append(newHash).append("\n");
        result.append("  Yeni Hash ile Doğrulama: ").append(passwordEncoder.matches(password, newHash) ? "✅ Başarılı" : "❌ Başarısız").append("\n");
        result.append("  Eski Hash ile Yeni Şifre: ").append(passwordEncoder.matches(password, user.getPassword()) ? "✅ Eşleşiyor" : "❌ Eşleşmiyor").append("\n\n");
        
        // Veritabanındaki tüm kullanıcıların şifre formatını kontrol et
        result.append("=== TÜM KULLANICILARIN ŞİFRE FORMATI ===\n");
        List<User> allUsers = userRepository.findAll();
        for (User u : allUsers) {
            boolean isBCrypt = u.getPassword().startsWith("$2a$") || u.getPassword().startsWith("$2b$");
            result.append(String.format("  %s: %s (%s)\n", 
                u.getEmail(), 
                isBCrypt ? "✅ BCrypt" : "❌ BCrypt DEĞİL", 
                u.getPassword().substring(0, Math.min(30, u.getPassword().length())) + "..."));
        }
        
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.TEXT_PLAIN);
        
        return ResponseEntity.ok()
                .headers(headers)
                .body(result.toString());
    }

    @GetMapping("/test/export")
    public ResponseEntity<String> exportDataToTxt() {
        StringBuilder content = new StringBuilder();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd.MM.yyyy HH:mm:ss");

        content.append("=".repeat(80)).append("\n");
        content.append("STAGEPASS VERİTABANI TEST VERİLERİ\n");
        content.append("=".repeat(80)).append("\n\n");

        // Kullanıcılar
        List<User> users = userRepository.findAll();
        content.append("KULLANICILAR (").append(users.size()).append(" adet)\n");
        content.append("-".repeat(80)).append("\n");
        for (User user : users) {
            content.append(String.format("ID: %d\n", user.getId()));
            content.append(String.format("  Email: %s\n", user.getEmail()));
            content.append(String.format("  Ad Soyad: %s %s\n", user.getFirstName(), user.getLastName()));
            content.append(String.format("  Telefon: %s\n", user.getPhoneNumber()));
            content.append(String.format("  Rol: %s\n", user.getRole()));
            content.append(String.format("  Aktif: %s\n", user.getIsActive() ? "Evet" : "Hayır"));
            content.append(String.format("  Şifre Hash (ilk 30 karakter): %s...\n", 
                user.getPassword().substring(0, Math.min(30, user.getPassword().length()))));
            content.append(String.format("  Şifre BCrypt formatında: %s\n", 
                (user.getPassword().startsWith("$2a$") || user.getPassword().startsWith("$2b$")) ? "Evet" : "HAYIR!"));
            content.append(String.format("  Oluşturulma: %s\n", 
                user.getCreatedAt() != null ? user.getCreatedAt().format(formatter) : "N/A"));
            content.append(String.format("  Son Giriş: %s\n", 
                user.getLastLoginAt() != null ? user.getLastLoginAt().format(formatter) : "Henüz giriş yapılmadı"));
            content.append(String.format("  Toplam Gösteri: %d\n", user.getTotalShowsAttended()));
            content.append(String.format("  Ödül Puanı: %d\n", user.getRewardPoints()));
            content.append("\n");
        }

        // Şehirler
        List<City> cities = cityRepository.findAll();
        content.append("\n").append("=".repeat(80)).append("\n");
        content.append("ŞEHİRLER (").append(cities.size()).append(" adet)\n");
        content.append("-".repeat(80)).append("\n");
        for (City city : cities) {
            content.append(String.format("ID: %d\n", city.getId()));
            content.append(String.format("  İsim: %s\n", city.getName()));
            content.append(String.format("  Ülke: %s\n", city.getCountry()));
            content.append(String.format("  Açıklama: %s\n", city.getDescription()));
            content.append(String.format("  Aktif: %s\n", city.getIsActive() ? "Evet" : "Hayır"));
            content.append("\n");
        }

        // Tiyatrolar
        List<Theater> theaters = theaterRepository.findAll();
        content.append("\n").append("=".repeat(80)).append("\n");
        content.append("TİYATROLAR (").append(theaters.size()).append(" adet)\n");
        content.append("-".repeat(80)).append("\n");
        for (Theater theater : theaters) {
            content.append(String.format("ID: %d\n", theater.getId()));
            content.append(String.format("  İsim: %s\n", theater.getName()));
            content.append(String.format("  Şehir: %s\n", theater.getCity().getName()));
            content.append(String.format("  Adres: %s\n", theater.getAddress()));
            content.append(String.format("  Telefon: %s\n", theater.getPhoneNumber()));
            content.append(String.format("  Email: %s\n", theater.getEmail()));
            content.append(String.format("  Toplam Koltuk: %d\n", theater.getTotalSeats()));
            content.append(String.format("  Açıklama: %s\n", theater.getDescription()));
            content.append(String.format("  Aktif: %s\n", theater.getIsActive() ? "Evet" : "Hayır"));
            content.append("\n");
        }

        // Gösteriler
        List<Show> shows = showRepository.findAll();
        content.append("\n").append("=".repeat(80)).append("\n");
        content.append("GÖSTERİLER (").append(shows.size()).append(" adet)\n");
        content.append("-".repeat(80)).append("\n");
        for (Show show : shows) {
            content.append(String.format("ID: %d\n", show.getId()));
            content.append(String.format("  Başlık: %s\n", show.getTitle()));
            content.append(String.format("  Tiyatro: %s\n", show.getTheater().getName()));
            content.append(String.format("  Tarih/Saat: %s\n", 
                show.getShowDateTime().format(DateTimeFormatter.ofPattern("dd.MM.yyyy HH:mm"))));
            content.append(String.format("  Süre: %d dakika\n", show.getDuration()));
            content.append(String.format("  Temel Fiyat: %.2f ₺\n", show.getBasePrice()));
            content.append(String.format("  Tür: %s\n", show.getGenre()));
            content.append(String.format("  Yaş Sınırı: %s\n", show.getAgeLimit()));
            content.append(String.format("  Durum: %s\n", show.getStatus()));
            content.append(String.format("  Açıklama: %s\n", show.getDescription()));
            content.append("\n");
        }

        // Koltuklar
        List<Seat> seats = seatRepository.findAll();
        content.append("\n").append("=".repeat(80)).append("\n");
        content.append("KOLTUKLAR (").append(seats.size()).append(" adet)\n");
        content.append("-".repeat(80)).append("\n");
        content.append("İlk 20 koltuk gösteriliyor...\n\n");
        int seatCount = 0;
        for (Seat seat : seats) {
            if (seatCount++ >= 20) break;
            content.append(String.format("ID: %d | Tiyatro: %s | Bölüm: %s | Sıra: %s | Koltuk: %s | Tip: %s | Fiyat: %.2f ₺\n",
                seat.getId(), seat.getTheater().getName(), seat.getSection(), 
                seat.getRowNumber(), seat.getSeatNumber(), seat.getSeatType(), seat.getPrice()));
        }
        if (seats.size() > 20) {
            content.append(String.format("\n... ve %d koltuk daha\n", seats.size() - 20));
        }

        // Biletler
        List<Ticket> tickets = ticketRepository.findAll();
        content.append("\n").append("=".repeat(80)).append("\n");
        content.append("BİLETLER (").append(tickets.size()).append(" adet)\n");
        content.append("-".repeat(80)).append("\n");
        for (Ticket ticket : tickets) {
            content.append(String.format("ID: %d\n", ticket.getId()));
            content.append(String.format("  Bilet No: %s\n", ticket.getTicketNumber()));
            content.append(String.format("  Kullanıcı: %s %s (%s)\n", 
                ticket.getUser().getFirstName(), ticket.getUser().getLastName(), ticket.getUser().getEmail()));
            content.append(String.format("  Gösteri: %s\n", ticket.getShow().getTitle()));
            content.append(String.format("  Fiyat: %.2f ₺\n", ticket.getPrice()));
            content.append(String.format("  Toplam Fiyat: %.2f ₺\n", ticket.getTotalPrice()));
            content.append(String.format("  Durum: %s\n", ticket.getStatus()));
            content.append(String.format("  Satın Alma: %s\n", 
                ticket.getPurchaseDate().format(formatter)));
            content.append("\n");
        }

        // Ödemeler
        List<Payment> payments = paymentRepository.findAll();
        content.append("\n").append("=".repeat(80)).append("\n");
        content.append("ÖDEMELER (").append(payments.size()).append(" adet)\n");
        content.append("-".repeat(80)).append("\n");
        for (Payment payment : payments) {
            content.append(String.format("ID: %d\n", payment.getId()));
            content.append(String.format("  Ödeme No: %s\n", payment.getPaymentNumber()));
            content.append(String.format("  Bilet: %s\n", payment.getTicket().getTicketNumber()));
            content.append(String.format("  Tutar: %.2f ₺\n", payment.getAmount()));
            content.append(String.format("  Yöntem: %s\n", payment.getMethod()));
            content.append(String.format("  Durum: %s\n", payment.getStatus()));
            content.append(String.format("  Tarih: %s\n", 
                payment.getPaymentDate().format(formatter)));
            content.append("\n");
        }

        // Ödüller
        List<UserReward> rewards = userRewardRepository.findAll();
        content.append("\n").append("=".repeat(80)).append("\n");
        content.append("ÖDÜLLER (").append(rewards.size()).append(" adet)\n");
        content.append("-".repeat(80)).append("\n");
        for (UserReward reward : rewards) {
            content.append(String.format("ID: %d\n", reward.getId()));
            content.append(String.format("  Kullanıcı: %s %s (%s)\n", 
                reward.getUser().getFirstName(), reward.getUser().getLastName(), reward.getUser().getEmail()));
            content.append(String.format("  Ödül Adı: %s\n", reward.getRewardName()));
            content.append(String.format("  Puan: %d / %d\n", reward.getPointsEarned(), reward.getPointsRequired()));
            content.append(String.format("  Durum: %s\n", reward.getStatus()));
            content.append(String.format("  Kazanma: %s\n", 
                reward.getEarnedDate().format(formatter)));
            content.append("\n");
        }

        content.append("\n").append("=".repeat(80)).append("\n");
        content.append("RAPOR OLUŞTURULMA TARİHİ: ").append(java.time.LocalDateTime.now().format(formatter)).append("\n");
        content.append("=".repeat(80)).append("\n");

        // Dosyaya yaz
        try {
            String fileName = "stagepass_test_data_" + java.time.LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss")) + ".txt";
            try (FileWriter writer = new FileWriter(fileName)) {
                writer.write(content.toString());
            }
            
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.TEXT_PLAIN);
            headers.setContentDispositionFormData("attachment", fileName);
            
            return ResponseEntity.ok()
                    .headers(headers)
                    .body(content.toString());
        } catch (IOException e) {
            return ResponseEntity.internalServerError()
                    .body("Dosya yazma hatası: " + e.getMessage() + "\n\n" + content.toString());
        }
    }
}
