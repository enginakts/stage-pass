package com.stagepass.stagepass.repository;

import com.stagepass.stagepass.model.UserReward;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface UserRewardRepository extends JpaRepository<UserReward, Long> {
    
    List<UserReward> findByUserIdOrderByEarnedDateDesc(Long userId);
    
    List<UserReward> findByUserIdAndStatusOrderByEarnedDateDesc(Long userId, UserReward.RewardStatus status);
    
    @Query("SELECT ur FROM UserReward ur WHERE ur.user.id = :userId AND ur.status = 'ACTIVE' ORDER BY ur.earnedDate DESC")
    List<UserReward> findActiveRewardsByUserId(@Param("userId") Long userId);
    
    @Query("SELECT SUM(ur.pointsEarned) FROM UserReward ur WHERE ur.user.id = :userId AND ur.status = 'ACTIVE'")
    Integer getTotalActivePointsByUserId(@Param("userId") Long userId);
}
