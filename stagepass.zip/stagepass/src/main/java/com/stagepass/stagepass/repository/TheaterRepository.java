package com.stagepass.stagepass.repository;

import com.stagepass.stagepass.model.Theater;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface TheaterRepository extends JpaRepository<Theater, Long> {
    
    List<Theater> findByCityIdAndIsActiveTrue(Long cityId);
    
    @Query("SELECT t FROM Theater t WHERE t.city.id = :cityId AND t.isActive = true ORDER BY t.name")
    List<Theater> findActiveTheatersByCityId(@Param("cityId") Long cityId);
    
    @Query("SELECT t FROM Theater t WHERE t.city.id = :cityId AND t.isActive = true AND LOWER(t.name) LIKE LOWER(CONCAT('%', :name, '%'))")
    List<Theater> findActiveTheatersByCityIdAndNameContaining(@Param("cityId") Long cityId, @Param("name") String name);

    Optional<Theater> findByNameIgnoreCaseAndCityId(String name, Long cityId);

    List<Theater> findByIsActiveTrueOrderByName();

    @Query("SELECT t FROM Theater t JOIN FETCH t.city WHERE t.isActive = true ORDER BY t.name")
    List<Theater> findActiveTheatersWithCity();

    long countByCityId(Long cityId);
}
