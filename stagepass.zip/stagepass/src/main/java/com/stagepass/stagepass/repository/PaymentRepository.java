package com.stagepass.stagepass.repository;

import com.stagepass.stagepass.model.Payment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Repository
public interface PaymentRepository extends JpaRepository<Payment, Long> {
    
    Optional<Payment> findByPaymentNumber(String paymentNumber);
    
    List<Payment> findByTicketIdOrderByPaymentDateDesc(Long ticketId);
    
    @Query("SELECT p FROM Payment p WHERE p.ticket.user.id = :userId ORDER BY p.paymentDate DESC")
    List<Payment> findByUserIdOrderByPaymentDateDesc(@Param("userId") Long userId);
    
    @Query("SELECT p FROM Payment p WHERE p.status = :status AND p.paymentDate >= :startDate AND p.paymentDate <= :endDate")
    List<Payment> findByStatusAndDateRange(@Param("status") Payment.PaymentStatus status, 
                                          @Param("startDate") LocalDateTime startDate, 
                                          @Param("endDate") LocalDateTime endDate);
    
    @Query("SELECT SUM(p.amount) FROM Payment p WHERE p.ticket.user.id = :userId AND p.status = 'COMPLETED'")
    Double getTotalSpentByUserId(@Param("userId") Long userId);

    boolean existsByTicketIdAndStatus(Long ticketId, Payment.PaymentStatus status);

    Optional<Payment> findTopByTicketIdOrderByPaymentDateDesc(Long ticketId);

    @Query("SELECT COALESCE(SUM(p.amount), 0) FROM Payment p WHERE p.status = 'COMPLETED'")
    Double getTotalCompletedAmount();

    List<Payment> findTop5ByOrderByPaymentDateDesc();
}
