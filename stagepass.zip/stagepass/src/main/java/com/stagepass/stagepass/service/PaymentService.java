package com.stagepass.stagepass.service;

import com.stagepass.stagepass.model.Payment;
import com.stagepass.stagepass.model.Ticket;
import com.stagepass.stagepass.model.User;
import com.stagepass.stagepass.repository.PaymentRepository;
import com.stagepass.stagepass.repository.TicketRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Optional;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class PaymentService {

    private final TicketRepository ticketRepository;
    private final PaymentRepository paymentRepository;

    @Transactional(readOnly = true)
    public Ticket getTicketForUser(Long ticketId, User user) {
        if (user == null) {
            throw new IllegalStateException("Lütfen önce giriş yapın.");
        }
        return ticketRepository.findByIdAndUserId(ticketId, user.getId())
            .orElseThrow(() -> new IllegalArgumentException("Bilet bulunamadı veya bu kullanıcıya ait değil."));
    }

    @Transactional(readOnly = true)
    public boolean isTicketAlreadyPaid(Long ticketId) {
        return paymentRepository.existsByTicketIdAndStatus(ticketId, Payment.PaymentStatus.COMPLETED);
    }

    @Transactional
    public Payment processCreditCardPayment(Ticket ticket, String cardHolder, String cardNumber, String expiry, String cvv) {
        validateCardInput(cardHolder, cardNumber, expiry, cvv);

        if (isTicketAlreadyPaid(ticket.getId())) {
            throw new IllegalStateException("Bu bilet için ödeme zaten tamamlanmış.");
        }

        Payment payment = new Payment();
        payment.setTicket(ticket);
        payment.setAmount(Optional.ofNullable(ticket.getTotalPrice()).orElse(BigDecimal.ZERO));
        payment.setMethod(Payment.PaymentMethod.CREDIT_CARD);
        payment.setStatus(Payment.PaymentStatus.COMPLETED);
        payment.setPaymentDate(LocalDateTime.now());
        payment.setCompletedDate(LocalDateTime.now());
        payment.setPaymentNumber(generatePaymentNumber(ticket.getId()));
        payment.setTransactionId(UUID.randomUUID().toString().replace("-", "").substring(0, 12).toUpperCase());
        payment.setPaymentProvider("StagePassPay");
        payment.setNotes("Kredi kartı ile ödeme tamamlandı.");

        return paymentRepository.save(payment);
    }

    private void validateCardInput(String cardHolder, String cardNumber, String expiry, String cvv) {
        if (cardHolder == null || cardHolder.trim().length() < 3) {
            throw new IllegalArgumentException("Kart üzerindeki isim geçersiz.");
        }
        if (cardNumber == null || !cardNumber.replaceAll("\\s+", "").matches("\\d{13,19}")) {
            throw new IllegalArgumentException("Kart numarası geçersiz.");
        }
        if (expiry == null || !expiry.matches("^(0[1-9]|1[0-2])\\/\\d{2}$")) {
            throw new IllegalArgumentException("Son kullanma tarihi MM/YY formatında olmalıdır.");
        }
        if (cvv == null || !cvv.matches("\\d{3,4}")) {
            throw new IllegalArgumentException("CVV/CVC kodu geçersiz.");
        }
    }

    private String generatePaymentNumber(Long ticketId) {
        String random = UUID.randomUUID().toString().replace("-", "").substring(0, 6).toUpperCase();
        return String.format("PAY-%d-%s", ticketId, random);
    }
}

