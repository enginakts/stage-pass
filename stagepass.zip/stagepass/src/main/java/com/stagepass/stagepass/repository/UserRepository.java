package com.stagepass.stagepass.repository;

import com.stagepass.stagepass.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {
    
    Optional<User> findByEmail(String email);
    
    boolean existsByEmail(String email);
    
    @Query("SELECT u FROM User u WHERE u.email = :email AND u.isActive = true")
    Optional<User> findActiveUserByEmail(@Param("email") String email);
    
    @Query("SELECT COUNT(t) FROM Ticket t WHERE t.user.id = :userId AND t.status = 'USED'")
    Long countUsedTicketsByUserId(@Param("userId") Long userId);

    List<User> findTop5ByOrderByCreatedAtDesc();
}
