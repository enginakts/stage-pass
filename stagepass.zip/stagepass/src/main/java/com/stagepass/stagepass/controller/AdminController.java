package com.stagepass.stagepass.controller;

import com.stagepass.stagepass.model.City;
import com.stagepass.stagepass.model.Payment;
import com.stagepass.stagepass.model.Show;
import com.stagepass.stagepass.model.Theater;
import com.stagepass.stagepass.model.Ticket;
import com.stagepass.stagepass.model.User;
import com.stagepass.stagepass.repository.CityRepository;
import com.stagepass.stagepass.repository.PaymentRepository;
import com.stagepass.stagepass.repository.ShowRepository;
import com.stagepass.stagepass.repository.TheaterRepository;
import com.stagepass.stagepass.repository.TicketRepository;
import com.stagepass.stagepass.repository.UserRepository;
import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;
import java.util.stream.Collectors;

@Controller
@RequestMapping("/admin")
@RequiredArgsConstructor
public class AdminController {

    private final UserRepository userRepository;
    private final ShowRepository showRepository;
    private final TicketRepository ticketRepository;
    private final PaymentRepository paymentRepository;
    private final TheaterRepository theaterRepository;
    private final CityRepository cityRepository;

    @Value("${stagepass.upload-dir:uploads}")
    private String uploadDir;

    @GetMapping
    public String dashboard(HttpSession session, Model model) {
        User user = (User) session.getAttribute("user");
        if (user == null) {
            return "redirect:/login";
        }
        if (user.getRole() != User.Role.ADMIN) {
            return "redirect:/";
        }

        long totalUsers = userRepository.count();
        long totalShows = showRepository.count();
        long totalTickets = ticketRepository.count();
        long totalPayments = paymentRepository.count();
        Double completedAmount = paymentRepository.getTotalCompletedAmount();
        BigDecimal totalRevenue = completedAmount != null ? BigDecimal.valueOf(completedAmount.doubleValue()) : BigDecimal.ZERO;

        List<Show> upcomingShows = showRepository.findActiveShowsFromDate(LocalDateTime.now());
        if (upcomingShows.size() > 5) {
            upcomingShows = upcomingShows.subList(0, 5);
        }

        List<Ticket> recentTickets = ticketRepository.findTop5ByOrderByPurchaseDateDesc();
        List<Payment> recentPayments = paymentRepository.findTop5ByOrderByPaymentDateDesc();
        List<User> recentUsers = userRepository.findTop5ByOrderByCreatedAtDesc();

        model.addAttribute("admin", user);
        model.addAttribute("totalUsers", totalUsers);
        model.addAttribute("totalShows", totalShows);
        model.addAttribute("totalTickets", totalTickets);
        model.addAttribute("totalPayments", totalPayments);
        model.addAttribute("totalRevenue", totalRevenue);
        model.addAttribute("upcomingShows", upcomingShows);
        model.addAttribute("recentTickets", recentTickets);
        model.addAttribute("recentPayments", recentPayments);
        model.addAttribute("recentUsers", recentUsers);

        return "admin/dashboard";
    }

    @GetMapping("/theaters")
    public String manageTheaters(HttpSession session, Model model) {
        User admin = (User) session.getAttribute("user");
        if (admin == null) {
            return "redirect:/login";
        }
        if (admin.getRole() != User.Role.ADMIN) {
            return "redirect:/";
        }

        List<Theater> theaters = theaterRepository.findAll();
        model.addAttribute("admin", admin);
        model.addAttribute("theaters", theaters);
        model.addAttribute("cities", cityRepository.findByIsActiveTrueOrderByName());
        return "admin/theaters";
    }

    @PostMapping("/theaters")
    public String createTheater(@RequestParam String name,
                                @RequestParam String address,
                                @RequestParam(required = false) String description,
                                @RequestParam(required = false) String phoneNumber,
                                @RequestParam(required = false) String email,
                                @RequestParam Integer totalSeats,
                                @RequestParam Long cityId,
                                @RequestParam(required = false) String openedDate,
                                @RequestParam(value = "imageFile", required = false) MultipartFile imageFile,
                                HttpSession session,
                                RedirectAttributes redirectAttributes) {
        User admin = (User) session.getAttribute("user");
        if (admin == null) {
            return "redirect:/login";
        }
        if (admin.getRole() != User.Role.ADMIN) {
            return "redirect:/";
        }

        try {
            var city = cityRepository.findById(Objects.requireNonNull(cityId, "cityId"))
                .orElseThrow(() -> new IllegalArgumentException("Seçilen şehir bulunamadı."));

            Theater theater = new Theater();
            theater.setName(name.trim());
            theater.setAddress(address.trim());
            theater.setDescription(description);
            theater.setPhoneNumber(phoneNumber);
            theater.setEmail(email);
            theater.setTotalSeats(totalSeats);
            theater.setIsActive(true);
            if (openedDate != null && !openedDate.isBlank()) {
                theater.setOpenedDate(LocalDate.parse(openedDate));
            } else {
                theater.setOpenedDate(LocalDate.now());
            }
            if (imageFile != null && !imageFile.isEmpty()) {
                theater.setImageUrl(storeTheaterImage(imageFile));
            }
            theater.setCity(city);

            theaterRepository.save(theater);
            redirectAttributes.addFlashAttribute("success", "Yeni tiyatro başarıyla eklendi!");
        } catch (RuntimeException ex) {
            redirectAttributes.addFlashAttribute("error", ex.getMessage());
        } catch (Exception ex) {
            redirectAttributes.addFlashAttribute("error", "Görsel yüklenirken bir hata oluştu: " + ex.getMessage());
        }

        return "redirect:/admin/theaters";
    }

    @GetMapping("/cities")
    public String manageCities(HttpSession session, Model model) {
        User admin = (User) session.getAttribute("user");
        if (admin == null) {
            return "redirect:/login";
        }
        if (admin.getRole() != User.Role.ADMIN) {
            return "redirect:/";
        }

        List<City> cities = cityRepository.findAllByOrderByNameAsc();
        Map<Long, Long> theaterCounts = cities.stream()
            .collect(Collectors.toMap(City::getId, city -> theaterRepository.countByCityId(city.getId())));

        model.addAttribute("admin", admin);
        model.addAttribute("cities", cities);
        model.addAttribute("theaterCounts", theaterCounts);
        return "admin/cities";
    }

    @PostMapping("/cities")
    public String createCity(@RequestParam String name,
                             @RequestParam(required = false) String country,
                             @RequestParam(required = false) String description,
                             @RequestParam(value = "isActive", required = false) Boolean isActive,
                             HttpSession session,
                             RedirectAttributes redirectAttributes) {
        User admin = (User) session.getAttribute("user");
        if (admin == null) {
            return "redirect:/login";
        }
        if (admin.getRole() != User.Role.ADMIN) {
            return "redirect:/";
        }

        try {
            if (!StringUtils.hasText(name)) {
                throw new IllegalArgumentException("Şehir adı zorunludur.");
            }
            String trimmedName = name.trim();
            if (cityRepository.existsByNameIgnoreCase(trimmedName)) {
                throw new IllegalArgumentException("Bu şehir zaten kayıtlı.");
            }

            City city = new City();
            city.setName(trimmedName);
            city.setCountry(StringUtils.hasText(country) ? country.trim() : "Türkiye");
            city.setDescription(StringUtils.hasText(description) ? description.trim() : null);
            city.setIsActive(isActive == null || isActive);

            cityRepository.save(city);
            redirectAttributes.addFlashAttribute("success", "Yeni şehir başarıyla eklendi!");
        } catch (RuntimeException ex) {
            redirectAttributes.addFlashAttribute("error", ex.getMessage());
        }

        return "redirect:/admin/cities";
    }

    private String storeTheaterImage(MultipartFile imageFile) throws Exception {
        String originalFilename = Objects.requireNonNullElse(imageFile.getOriginalFilename(), "theater-image");
        if (!StringUtils.hasText(originalFilename)) {
            originalFilename = "theater-image";
        }
        String cleanedFilename = StringUtils.cleanPath(Objects.requireNonNull(originalFilename));
        String extension = "";
        int extIndex = cleanedFilename.lastIndexOf('.');
        if (extIndex >= 0) {
            extension = cleanedFilename.substring(extIndex);
        }

        String fileName = UUID.randomUUID() + extension;
        Path storagePath = Paths.get(uploadDir, "theaters").toAbsolutePath().normalize();
        Files.createDirectories(storagePath);
        Path targetFile = storagePath.resolve(fileName);
        Files.copy(imageFile.getInputStream(), targetFile, StandardCopyOption.REPLACE_EXISTING);
        return "/uploads/theaters/" + fileName;
    }
}

