package com.stagepass.stagepass.model;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Set;

@Entity
@Table(name = "tickets")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Ticket {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(unique = true, nullable = false)
    private String ticketNumber;
    
    @Column(nullable = false)
    private BigDecimal price;
    
    @Column(nullable = false)
    private BigDecimal totalPrice;
    
    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private TicketStatus status = TicketStatus.ACTIVE;
    
    @Column(nullable = false)
    private LocalDateTime purchaseDate = LocalDateTime.now();
    
    @Column
    private LocalDateTime cancellationDate;
    
    @Column
    private String cancellationReason;
    
    @Column
    private String qrCode;
    
    // Bilet sahibi
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;
    
    // Bilet hangi gösteri için
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "show_id", nullable = false)
    private Show show;
    
    // Bilet hangi koltuk için
    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "seat_id", nullable = false)
    private Seat seat;
    
    // Biletin ödeme kayıtları
    @OneToMany(mappedBy = "ticket", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private Set<Payment> payments;
    
    public enum TicketStatus {
        ACTIVE, CANCELLED, USED, EXPIRED, REFUNDED
    }
    
    // Bilet iptal edilebilir mi kontrolü (gösteri saatinden 12 saat öncesine kadar)
    public boolean canBeCancelled() {
        if (status != TicketStatus.ACTIVE) {
            return false;
        }
        LocalDateTime cancellationDeadline = show.getShowDateTime().minusHours(12);
        return LocalDateTime.now().isBefore(cancellationDeadline);
    }
    
    // Bilet güncellenebilir mi kontrolü
    public boolean canBeUpdated() {
        return canBeCancelled() && status == TicketStatus.ACTIVE;
    }
}
